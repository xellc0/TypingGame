﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;

namespace Typing_Game
{
    public partial class Form1 : Form
    {

        string[] words = { "Halo", "kamu", "kucing", "Internet", "kuda", "komputer", "buku", "Selimut", "sepatu", "baju", "kaca", "Meja", "kursi", "pintu", "jendela", "langit", "bintang", "Bulan", "matahari", "tanah", "Mayat", "beban", "Kelas", "kamar", "botol", "Masjid", "Tisu basah", "Rumah kosong", "gunung", "Pantai" };

        Random rnd = new Random();

        int correct = 0;
        int incorrect = 0;

        WindowsMediaPlayer player = new WindowsMediaPlayer();
        public Form1()
        {
            InitializeComponent();

            lblword.Text = words[rnd.Next(0, words.Length) ];
            player.URL = "aboutyou.mp3"; 
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            player.controls.play();
        }

        private void checkGame(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            { 

                if (textBox1.Text == lblword.Text)
                {
                    correct++;
                    lblword.Text = words[rnd.Next(0, words.Length)];
                    textBox1.Text = null;
                }
                else
                {
                    incorrect++;
                    lblword.Text = words[rnd.Next(0, words.Length)];
                    textBox1.Text = null;
                }

                lblright.Text = "Correct: " + correct;
                lblwrong.Text = "Incorrect: " + incorrect;
            }
       
        }

        int timeLeft = 30; 
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (timeLeft > 0)
            {
                timeLeft = timeLeft - 1;
                lblMyTime.Text = timeLeft + " Seconds";
                btnRefresh.Enabled = false;

            }
            else
            { 
                btnRefresh.Visible = true;
                lblMessage.Text = "skill issue waktu habis!!";

            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Form1 F1 = new Form1();
            F1.Show();
            this.Hide();

        }
    }
}
